<?php  
if(isset($_POST["submit"])){  
  
if(!empty($_POST['user']) && !empty($_POST['pass'])) {  
    $user=$_POST['user'];  
    $pass=$_POST['pass'];  
  
    $con=mysqli_connect('localhost','root','') or die(mysqli_error());  
    $db=mysqli_select_db($con,'photography') or die("cannot select DB");  
  
    $query="SELECT * FROM login WHERE Uname='$user' AND Password='$pass'";  
    $re=mysqli_query($con,$query);
    $r=mysqli_fetch_array($re);
    #$numrows=mysqli_num_rows($r);  
    $c=mysqli_num_rows($re);
    if($c==1){
  
    /* Redirect browser */  
    header("Location: addpic.php");  
      
    } else {  
    echo "Invalid username or password!";  
    }  
  
} 
}  
?>
<html>
    <head>
        <title>Photography Portfolio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
    <style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
    float: right;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<script>
    function night()
    {
        document.body.style.background='black';
        document.body.style.color='white';
        document.getElementById('footer').style.background='#696969	';
        document.getElementById('footer').style.color='white';
        document.getElementByClassName('cotainer').style.background='#808080';
    }
</script>
    </head>
    <body>
     
            
        <div class="top-nav">
            
            <center>
            <label class="switch">
                    <input type="checkbox" unchecked onclick="night()">
                    <span class="slider round"></span>
            </label><a href="index.php">Home</a>
            <a href="traveled.php">Traveld</a>
            <a href="#footer">About</a>
            <a href="login.php"  id=inside style="float:right;">Login</a><br></center>
            
        </div><br><br>
     
<center><h3>Login Here</h3>  
<form action="addpic.php" method="POST" style="padding:10px;">  
Username: <input type="text" name="user" required ><br><br>  
Password: <input type="password" name="pass" required><br><br>  
<input type="submit" value="Login" name="submit" style="color:white; width :150px;background-color:#00BFFF;height:40px; border:no-border;" ><br>  
<a href="forgot.php" style="font-size:12spx;color:blue;">Forgot Password ?</a>
</form> </center>
    <br><br><br><br><br><br><br><br>
<footer class="footer" id="footer">
            <p id="name">The AsKk Photos</p>
            <p>Call: +91 81 11 85 89 64</p>
            <p>This project webpage can be used for the various photographers in which they<br> can add photos which they have taken throughout their career</p>
            <div class="insta-logo">
                <img src="insta.ico" font-size="11px;" ><a href="https://www.instagram.com" syle="font-size:12px;">  @AsKK_Photos</a>
            </div>
        </footer>
  
</body>  
</html>   
