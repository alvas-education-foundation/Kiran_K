<html>
    <head>
        <title>Photography Portfolio</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
    <style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
    float: right;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<script>
    function night()
    {
        document.body.style.background='black';
        document.body.style.color='white';
        document.getElementById('footer').style.background='#696969	';
        document.getElementById('footer').style.color='white';
        document.getElementByClassName('cotainer').style.background='#808080';
    }
</script>
    </head>
    <body>
     
            
        <div class="top-nav">
            
            <center>
            <label class="switch">
                    <input type="checkbox" unchecked onclick="night()">
                    <span class="slider round"></span>
            </label><a href="index.php">Home</a>
            <a href="traveled.php">Traveld</a>
            <a href="#footer">About</a>
            <a href="login.php"  id=inside style="float:right;">Login</a><br></center>
            
        </div>
            <br><br>
        
        <br>
        <div class="travel-diary" style="margin-left: 20px;">
            <img src="iceland1.jpg" style="width: 30%;height: 40%; top: 30%">
            <img src="iceland2.jpg" style="width: 30%;height: 40%; margin-left: 10px;">
            <img src="iceland3.jpg" style="width: 30%;height: 40%;margin-left: 10px;">
            <br><br>
            <img src="iceland4.jpg" style="width: 30%;height: 40%;margin-left: 10px; ">    
            <img src="iceland5.jpg" style="width: 30%;height: 40%;margin-left: 10px;">
            
            <img src="iceland6.jpg" style="width: 30%;height: 40%; top: 30%;margin-left: 10px;">
            <br>
            <br>
            
        </div>
        
        
        
    <footer class="footer" id="footer">
            <p id="name">The AsKk Photos</p>
            <p>Call: +91 81 11 85 89 64</p>
        <p>This project webpage can be used for the various photographers in which they<br> can add photos which they have taken throughout their career</p>
            <div class="insta-logo">
                <img src="insta.ico" font-size="11px;" ><a href="https://www.instagram.com" syle="font-size:12px;">  @AsKK_Photos</a>
            </div>
        </footer>
    </body>
</html>