<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "photography");

  // Initialize message variable
  $msg = "";


  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
    
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);
      

  	// image file directory
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO images (image, text) VALUES ('$image', '$image_text')";
  	// execute query
      
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
        
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
    
  $result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
 <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="addpic.css">

</head>
<body>
<div class="top-nav">
            <center><a href="#">Home</a>
            <a href="traveled.php">Traveld</a>
            <a href="#footer">About</a>
            <a href="index.php"  id=inside style="float:right;">Logout</a></center>
    </div>
    <br>
    

  <center><form method="POST" action="addpic.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000" style="padding:40px;">
  	<div>
  	  <input type="file" name="image" style="padding:20px;">
  	</div>
  	<div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="image_text" 
      	placeholder="Say something about this image..."></textarea>
  	</div>
  	<div>
        <br>
  		<button  type="submit" name="upload" style="color:white; background-color:#00BFFF;height:40px; border:no-border;" >Upload Image</button>
        <button type="submit" name="delete "style="color:white; background-color:#00BFFF;height:40px; border:no-border;" >Delete image</button>
  	</div>
  </form></center>
    <br>
<div class="cotainer" style="width: 100% ;height:100%; background-color: whitesmoke; color: black; z-index: 0; display:inline-flex;">
            <?php
            echo "<table id='img_div'>";
            $i = 0;
    while ($row = mysqli_fetch_array($result)) 
    {
        if ($i == 0)
            echo "<tr>";            
      	echo "<td><img src='images/".$row['image']."'width=400px height=300px hspace=20px;></td>";
        if ($i == 2)
            echo "</tr>";
      //echo "</div>";
        $i+=1;
        if($i == 3)
            $i = 0;
        
    }
    echo "</table>";
  ?>
        
        </div>
    <footer class="footer" id="footer">
            <p id="name">The AsKk Photos</p>
            <p>Call: +91 81 11 85 89 64</p>
            <p>This project webpage can be used for the various photographers in which they<br> can add photos which they have taken throughout their career</p>
            <div class="insta-logo">
                <img src="insta.ico" font-size="11px;" ><a href="https://www.instagram.com" syle="font-size:12px;">  @AsKK_Photos</a>
            </div>
        </footer>
</body>
</html>